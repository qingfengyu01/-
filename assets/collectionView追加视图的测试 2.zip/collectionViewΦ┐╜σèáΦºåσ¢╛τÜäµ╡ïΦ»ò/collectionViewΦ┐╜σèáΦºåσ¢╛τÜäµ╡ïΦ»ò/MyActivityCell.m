//
//  MyActivityCell.m
//  collectionView追加视图的测试
//
//  Created by apple on 16/9/11.
//  Copyright © 2016年 cz.cn. All rights reserved.
//

#import "MyActivityCell.h"
#import "MyActivity.h"

#import "MyActivityImageCell.h"
@interface  MyActivityCell()<UICollectionViewDelegate,UICollectionViewDataSource>

@property (nonatomic, weak) UICollectionView *collectionView;

@end

@implementation MyActivityCell

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        
        UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc]init];
        flowLayout.itemSize = frame.size;
        flowLayout.minimumLineSpacing = 0;
        flowLayout.minimumInteritemSpacing = 0;
        flowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
        
        UICollectionView *collectionView = [[UICollectionView alloc]initWithFrame:frame collectionViewLayout:flowLayout];
        
        collectionView.backgroundColor = [UIColor yellowColor];
        
        [self.contentView addSubview:collectionView];
        collectionView.dataSource = self;
        collectionView.delegate = self;
        collectionView.pagingEnabled = YES;
        _collectionView = collectionView;
        
        [collectionView registerNib:[UINib nibWithNibName:@"MyActivityImageCell" bundle:nil] forCellWithReuseIdentifier:@"MyActivityImageCell"];
    }
    return self;
}

- (void)setActivity:(NSArray *)activity
{
     _activity = activity;
    
    [self.collectionView reloadData];
}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
   return  self.activity.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    MyActivityImageCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"MyActivityImageCell" forIndexPath:indexPath];
    
    cell.activity = self.activity[indexPath.row];
    
    return cell;
}

@end
