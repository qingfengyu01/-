//
//  MyActivityImageCell.h
//  collectionView追加视图的测试
//
//  Created by apple on 16/9/12.
//  Copyright © 2016年 cz.cn. All rights reserved.
//

#import <UIKit/UIKit.h>
@class  MyActivity;
@interface MyActivityImageCell : UICollectionViewCell

@property (nonatomic, strong) MyActivity *activity;

@end
