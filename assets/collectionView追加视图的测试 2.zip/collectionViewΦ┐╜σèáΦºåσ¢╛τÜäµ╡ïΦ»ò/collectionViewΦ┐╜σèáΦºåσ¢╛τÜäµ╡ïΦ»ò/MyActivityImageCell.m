//
//  MyActivityImageCell.m
//  collectionView追加视图的测试
//
//  Created by apple on 16/9/12.
//  Copyright © 2016年 cz.cn. All rights reserved.
//

#import "MyActivityImageCell.h"
#import "MyActivity.h"

#import "UIImageView+WebCache.h"
@interface MyActivityImageCell ()
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end

@implementation MyActivityImageCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setActivity:(MyActivity *)activity
{

    _activity = activity;
    
    [self.imageView sd_setImageWithURL:[NSURL URLWithString:activity.img]];

}

@end
