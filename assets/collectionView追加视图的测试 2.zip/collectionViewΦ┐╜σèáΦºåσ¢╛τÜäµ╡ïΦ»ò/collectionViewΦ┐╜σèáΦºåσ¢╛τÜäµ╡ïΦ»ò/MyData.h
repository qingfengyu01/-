//
//  MyData.h
//  解析数据
//
//  Created by iMac on 16/9/10.
//  Copyright © 2016年 iMac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyData : NSObject

@property (nonatomic, strong) NSArray *activities;

@property (nonatomic, strong) NSArray *focus;

@property (nonatomic, strong) NSArray *icons;


//+ (instancetype)dataWithDict:(NSDictionary *)dict;
//
//- (instancetype)initWithDict:(NSDictionary *)dict;

@end
