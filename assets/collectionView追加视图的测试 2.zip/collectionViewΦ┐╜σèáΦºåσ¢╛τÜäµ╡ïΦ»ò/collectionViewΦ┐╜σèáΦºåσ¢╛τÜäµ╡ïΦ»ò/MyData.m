//
//  MyData.m
//  解析数据
//
//  Created by iMac on 16/9/10.
//  Copyright © 2016年 iMac. All rights reserved.
//

#import "MyData.h"
#import "MyIcon.h"

#import "YYModel.h"
#import "MyActivity.h"
#import "MyFocu.h"
#import "MyIcon.h"

@implementation MyData

+ (NSDictionary *)modelContainerPropertyGenericClass {
    // value should be Class or Class name.
    return @{@"activities" : [MyActivity class],
             @"focus" : [MyFocu class],
             @"icons" : [MyIcon class]
             };
}


//+ (instancetype)dataWithDict:(NSDictionary *)dict
//{
//
//   return  [[self  alloc]initWithDict:dict];
//}
//
//- (instancetype)initWithDict:(NSDictionary *)dict
//{
//
//    if (self = [super init]) {
//        
//        [self setValuesForKeysWithDictionary:dict];
//
//        NSArray *icons = dict[@"icons"];
//        
//        NSMutableArray *tempIcons = [NSMutableArray array];
//        
//        // 遍历数组
//        
//        for (int i = 0; i < icons.count; i ++) {
//            
//            NSDictionary *d1 = icons[i];
//            
//            //字典转模型
//            
//            MyIcon *icon = [MyIcon iconWithDict:di];
//         
//            [tempIcons addObject:icon];
//        }
//        
//        
//        _icons = tempIcons.copy;
//        
//    }
//    
//    return self;
//}

@end
