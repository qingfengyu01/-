//
//  MyFocu.h
//  解析数据
//
//  Created by iMac on 16/9/10.
//  Copyright © 2016年 iMac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyFocu : NSObject

@property (nonatomic, copy) NSString * idStr;


@property (nonatomic, copy) NSString * img;
@property (nonatomic, copy) NSString * name;
@property (nonatomic, copy) NSString * toURL;

@end
