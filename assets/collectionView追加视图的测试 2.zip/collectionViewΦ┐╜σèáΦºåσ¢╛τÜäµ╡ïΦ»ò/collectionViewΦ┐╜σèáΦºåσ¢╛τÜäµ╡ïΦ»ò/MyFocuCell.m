//
//  MyFocuCell.m
//  collectionView追加视图的测试
//
//  Created by apple on 16/9/11.
//  Copyright © 2016年 cz.cn. All rights reserved.
//

#import "MyFocuCell.h"
#import "Masonry.h"
#import "MyFocu.h"

#import "UIImageView+WebCache.h"
@interface MyFocuCell ()

@property (nonatomic, weak) UIImageView *iconView;

@end
@implementation MyFocuCell

- (instancetype)initWithFrame:(CGRect)frame
{

    if (self = [super initWithFrame:frame]) {
        
     
        UIImageView *iconView = [[UIImageView alloc]init];
        
        [self addSubview:iconView];
        
        self.iconView = iconView;
        
        [iconView mas_makeConstraints:^(MASConstraintMaker *make) {
            
//            make.top.left.right.bottom.equalTo(self);
            
            make.top.left.equalTo(self).offset(5);
            make.bottom.right.equalTo(self).offset(-5);
            
        }];

    }
    return self;
}
- (void)setFocu:(MyFocu *)focu
{
    _focu = focu;
    
    [self.iconView sd_setImageWithURL:[NSURL URLWithString:focu.img]];
}

  // Configure the view for the selected state


@end
