//
//  MyFoodCell.m
//  collectionView追加视图的测试
//
//  Created by apple on 16/9/11.
//  Copyright © 2016年 cz.cn. All rights reserved.
//

#import "MyFoodCell.h"
#import "MyFood.h"

#import "UIImageView+WebCache.h"
@interface MyFoodCell ()

@property (weak, nonatomic) IBOutlet UIImageView *iconView;


@property (weak, nonatomic) IBOutlet UILabel *labName;

@end

@implementation MyFoodCell

- (void)setFood:(MyFood *)food
{

    _food = food;
    
    self.labName.text = food.brand_name;
    
    
    [self.iconView sd_setImageWithURL:[NSURL URLWithString:food.img]];
}

@end
