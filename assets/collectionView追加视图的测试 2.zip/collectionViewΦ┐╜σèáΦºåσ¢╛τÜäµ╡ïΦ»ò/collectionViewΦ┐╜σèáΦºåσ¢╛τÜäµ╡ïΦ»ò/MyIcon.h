//
//  MyIcon.h
//  解析数据
//
//  Created by iMac on 16/9/10.
//  Copyright © 2016年 iMac. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyIcon : NSObject

@property (nonatomic, copy) NSString * customURL;

@property (nonatomic, copy) NSString * idStr;
@property (nonatomic, copy) NSString * img;
@property (nonatomic, copy) NSString * name;

//+ (instancetype)iconWithDict:(NSDictionary *)dict;
//
//- (instancetype)initWithDict:(NSDictionary *)dict;

@end
