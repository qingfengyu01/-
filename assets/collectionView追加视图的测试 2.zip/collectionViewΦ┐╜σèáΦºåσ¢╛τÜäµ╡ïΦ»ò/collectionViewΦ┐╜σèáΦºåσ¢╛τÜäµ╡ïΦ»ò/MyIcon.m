//
//  MyIcon.m
//  解析数据
//
//  Created by iMac on 16/9/10.
//  Copyright © 2016年 iMac. All rights reserved.
//

#import "MyIcon.h"

@implementation MyIcon


+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"idStr" : @"id",
             
             };
}

//+ (instancetype)iconWithDict:(NSDictionary *)dict
//{
//    
//    return  [[self  alloc]initWithDict:dict];
//}
//
//- (instancetype)initWithDict:(NSDictionary *)dict
//{
//
//    if (self = [super init]) {
//        
//        [self setValuesForKeysWithDictionary:dict];
//    }
//    
//    return self;
//}
//
//- (void)setValue:(id)value forUndefinedKey:(NSString *)key
//{
//
//}

@end
