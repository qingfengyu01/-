//
//  MyIconCell.m
//  collectionView追加视图的测试
//
//  Created by apple on 16/9/11.
//  Copyright © 2016年 cz.cn. All rights reserved.
//

#import "MyIconCell.h"
#import "Masonry.h"
#import "MyIcon.h"
#import "UIImageView+WebCache.h"
@interface MyIconCell ()

@property (nonatomic, weak)UIImageView *iconView;

@property (nonatomic, weak) UILabel *labName;
@end

@implementation MyIconCell

- (instancetype)initWithFrame:(CGRect)frame
{

    if (self = [super initWithFrame:frame]) {
     
        UIImageView *iconView = [[UIImageView alloc]init];
        [self addSubview:iconView];
        _iconView = iconView;
        
        UILabel *labName = [[UILabel alloc]init];
        [self addSubview:labName];
        _labName = labName;
        labName.textAlignment = NSTextAlignmentCenter;
        labName.textColor = [UIColor blackColor];
        
        
        [labName mas_makeConstraints:^(MASConstraintMaker *make) {
           
            make.left.right.bottom.equalTo(self);
            make.height.mas_equalTo(30);
        }];
        
        [iconView mas_makeConstraints:^(MASConstraintMaker *make) {
           
            make.top.left.right.equalTo(self);
            make.bottom.equalTo(labName.mas_top);
            
//            make.center.equalTo(self);
        }];
        
    }
    return self;
}

- (void)setIcon:(MyIcon *)icon
{

    _icon = icon;
    
    [self.iconView sd_setImageWithURL:[NSURL URLWithString:icon.img]];
    
    self.labName.text = icon.name;

}


@end
