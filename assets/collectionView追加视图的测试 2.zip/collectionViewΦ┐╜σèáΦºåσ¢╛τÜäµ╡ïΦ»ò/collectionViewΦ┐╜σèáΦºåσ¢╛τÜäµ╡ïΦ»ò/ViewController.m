//
//  ViewController.m
//  collectionView追加视图的测试
//
//  Created by apple on 16/9/11.
//  Copyright © 2016年 cz.cn. All rights reserved.
//
#import "ViewController.h"

#import "AFNetworking.h"
#import "YYModel.h"

#import "MyData.h"
#import "MyFood.h"

#import "MyActivityCell.h"
#import "MyIconCell.h"
#import "MyFoodCell.h"
#import "MyFocuCell.h"


@interface ViewController ()<UICollectionViewDelegateFlowLayout,UICollectionViewDataSource>

@property (nonatomic, strong) MyData *data;

@property (nonatomic, strong) NSArray *foods;

@property (nonatomic, weak) UICollectionView *collectionView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc]init];
    flowLayout.minimumLineSpacing = 0;
    flowLayout.minimumInteritemSpacing = 0;
    
    UICollectionView *collectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, 375, 667) collectionViewLayout:flowLayout];
    
    collectionView.backgroundColor = [UIColor redColor];
    
    collectionView.delegate = self;
    collectionView.dataSource = self;
    
    [self.view addSubview:collectionView];
    self.collectionView = collectionView;
    
    // 注册 cell
    [collectionView registerClass:[MyActivityCell class] forCellWithReuseIdentifier:@"MyActivityCell"];
    [collectionView registerClass:[MyIconCell class] forCellWithReuseIdentifier:@"MyIconCell"];
    [collectionView registerClass:[MyFocuCell class] forCellWithReuseIdentifier:@"MyFocuCell"];
    
    [collectionView registerNib:[UINib nibWithNibName:@"MyFoodCell" bundle:nil] forCellWithReuseIdentifier:@"MyFood"];
    
    [collectionView registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"headerView"];

    
    // 请求数据
    AFHTTPSessionManager *manager = [[AFHTTPSessionManager alloc]init];
    manager.requestSerializer  = [[AFJSONRequestSerializer alloc]init];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/html", nil];
    
    NSDictionary *dict = @{@"call":@"1"};
    
    [manager POST:@"http://iosapi.itcast.cn/loveBeen/focus.json.php" parameters:dict progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            
            NSDictionary *dict = responseObject[@"data"];
            
            NSLog(@"%@",dict);
            //创建一个模型
            self.data = [MyData yy_modelWithDictionary:dict];
            
            // 整个是一个 字典
            
            
            [_collectionView reloadData];
        });

    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"%@",error);
    }];
    
    NSDictionary *d = @{@"call":@"2"};
    [manager POST:@"http://iosapi.itcast.cn/loveBeen/firstSell.json.php" parameters:d progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSLog(@"%@",responseObject);
        
        NSArray *dict = responseObject[@"data"];
        
        self.foods = [NSArray yy_modelArrayWithClass:[MyFood class] json:dict];
        
        [_collectionView reloadData];
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"%@",error);
    }];

}

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 4;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (section == 0) {
        return self.data == nil ? 0 : 1;
    }else if(section == 1){
        
    return self.data.icons.count;
        
    }else if (section == 2){
    
        return self.data.focus.count;
        
    }else{
        return self.foods.count;
    }
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
     MyActivityCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"MyActivityCell" forIndexPath:indexPath];
        
        cell.backgroundColor = [UIColor orangeColor];
        
        cell.activity = self.data.activities;
        
        return cell;
        
    }else if(indexPath.section == 1){
        
    MyIconCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"MyIconCell" forIndexPath:indexPath];
        
    cell.icon = self.data.icons[indexPath.row];
        
    return cell;
        
    }else if(indexPath.section== 2){
        
        MyFocuCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"MyFocuCell" forIndexPath:indexPath];
        
        cell.focu =  self.data.focus[indexPath.row];
        return cell;
        
    }else{
        MyFoodCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"MyFood" forIndexPath:indexPath];
        cell.food = self.foods[indexPath.row];
        return cell;
    }
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        return CGSizeMake(375, 150);
        
    }else if (indexPath.section == 1){
    
        return CGSizeMake(375 / 4.0, 375 / 4.0);
    }else if (indexPath.section == 2){
    
        return CGSizeMake(375, 150);
    
    }else{
        return CGSizeMake(375 / 2.0, 180);
    }
}



@end
